import React, {useEffect, useRef, useState} from 'react'
import './App.css'

const originsWhiteList = ['http://localhost:5174','http://localhost:5175']

class HostBus {
    constructor(private originsWhiteList: string[]) {
    }

    iframes: any[] = [];
    registerIframe(event: any) {
        const iframe = event.source;
        const origin = event.origin.trim('/');

        if (originsWhiteList.includes(origin)) {
            this.iframes.push(iframe);
        } else {
            console.error('BAD IFRAME ORIGIN')
        }
    }
    emit(action: any) {
        this.iframes.forEach(iframe => {
            iframe.postMessage(
                JSON.stringify(action), '*')
        })
    }
}

const bus = new HostBus(originsWhiteList);


function App() {
    const [menu, setMenu] = useState([])

    const sendToken = () => {
        const action = {type: 'TOKEN-CREATED', payload: {token: 'XXX-YYY'}}
        bus.emit(action)
    }

    useEffect(() => {
        window.addEventListener('message', (event) => {
            const action = JSON.parse(event.data)
            switch (action.type) {
                case 'MENU-SENT': {
                    // @ts-ignore
                    setMenu((prev) => [...prev, ...action.payload.items])
                }
                case 'IFRAME-LOADED': {
                    bus.registerIframe(event)
                   break;
                }
                case 'REDUX-ACTION':{
                    bus.emit(action)
                }
            }
        })
    }, [])


    return (
        <div className="App">
            <h1>I am HOST</h1>
            <hr/>
            <ul>
                {
                    menu.map((item: any, index) => <li key={index}>{item.title}</li>)
                }
            </ul>
            <hr/>
            <button onClick={sendToken}>send token</button>
            <iframe src={'http://localhost:5174/'} style={{border: 'none'}}></iframe>
            <iframe src={'http://localhost:5175/'} style={{border: 'none'}}></iframe>
        </div>
    )
}

export default App
