import {useEffect, useState} from 'react'
import './App.css'

class MFIframeBus {
    constructor(private hostOrigin: string) {
        window.addEventListener('message', (event) => {
                /*  if (event.origin !== "http://localhost:5173")
                      return;*/

                const action = JSON.parse(event.data)
                if (this.subscribers[action.type]) {
                    this.subscribers[action.type].forEach((subscriber: any) => {
                        subscriber(action)
                    })
                }
            }
        )
    }

    subscribers: any = {
        // 'action-typr': []
    }

    registerMe() {
        const action = {
            type: 'IFRAME-LOADED'
        }
        window.parent.postMessage(JSON.stringify(action), this.hostOrigin)
    }

    emit(action: any) {
        window.parent.postMessage(JSON.stringify(action), this.hostOrigin)
    }

    subscribe(actionType: string, subscriber: any) {
        if (!this.subscribers[actionType]) this.subscribers[actionType] = []

        this.subscribers[actionType].push(subscriber)

        return () => {
            this.subscribers[actionType] = this.subscribers[actionType].filter((s: any) => s !== subscriber)
        }
    }
}

const mFBus = new MFIframeBus('http://localhost:5173')

function App() {
    const [token, setToken] = useState('')
    const [message, setMessage] = useState('')

    // const mFBus = useBus();

    useEffect(() => {
        return mFBus.subscribe('TOKEN-CREATED', (action: any) => {
            setToken(action.payload.token)
        })
    }, [])

    useEffect(() => {
        return mFBus.subscribe('REDUX-ACTION', (action: any) => {
            switch (action.payload.originalAction.type) {
                case 'CART-PRODUCT-DELETED':
                    setMessage(action.payload.originalAction.payload.productId)
            }
        })
    }, [])


    useEffect(() => {
        mFBus.registerMe()
    }, [])

    useEffect(() => {
        const action = {
            type: 'MENU-SENT', payload: {
                items: [
                    {title: 'home'},
                    {title: 'other'},
                ]
            }
        }

        mFBus.emit(action)
    }, [])

    return (
        <div className="App">
            <h3>
                I am microfront, token: {token},
                product deleted: {message}
            </h3>
        </div>
    )
}

export default App
