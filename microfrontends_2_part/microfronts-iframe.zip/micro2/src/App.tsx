import {useEffect, useState} from 'react'
import './App.css'

function App() {
    const [token, setToken] = useState('')

    useEffect(() => {
        window.addEventListener('message', (event) => {
            const action = JSON.parse(event.data)
            switch (action.type) {
                case 'TOKEN-CREATED': {
                    setToken(action.payload.token)
                }
            }
        })
    }, [])


    useEffect(() => {
        const action = {
            type: 'MENU-SENT', payload: {
                items: [
                    {title: 'mf-2-menu-item'},
                    {title: 'mf-2-menu-item-other'},
                ]
            }
        }

        window.parent.postMessage(JSON.stringify(action), 'http://localhost:5173')

    }, [])

    useEffect(() => {
        const action = {
            type: 'IFRAME-LOADED'
        }
        window.parent.postMessage(JSON.stringify(action), 'http://localhost:5173')

    }, [])

    const onProductDeletedHandler = () => {
        const ipcAction = {
            type: 'REDUX-ACTION',
            payload: {
                originalAction: {
                    type: 'CART-PRODUCT-DELETED', payload: {
                        productId: 121
                    },
                    source: 'MICROFRONT2'
                }
            }
        }

        window.parent.postMessage(JSON.stringify(ipcAction), 'http://localhost:5173')
    }

    return (
        <div className="App">
            <h3>
                I am microfront, token: {token}, <button onClick={onProductDeletedHandler}>hello to first
                microfront</button>
            </h3>
        </div>
    )
}

export default App
